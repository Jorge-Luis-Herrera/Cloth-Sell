# Exportación de chat de WhatsApp: Jeni Sis
Fecha de exportación: November 25, 2026 at 3:26 PM

---

## November 21, 2026

[4:38 PM] **Jeni Sis:** Psss Tati

[4:38 PM] **Jeni Sis:** En qué andas

[4:38 PM] **Jeni Sis:** Cómo vas

[4:38 PM] **Jeni Sis:** Vienen hoy?

[6:03 PM] **Tú:** No creo

[6:03 PM] **Tú:** Ya es muy tarde

[6:29 PM] **Jeni Sis:** Por qué no me has presentado a tu novia

[6:29 PM] **Jeni Sis:** [Sticker]

[6:33 PM] **Tú:**
> _Jeni Sis: Por qué no me has presentado a tu novia_
Cuál de todas ? 🤣

[9:35 PM] **Jeni Sis:** Cuantas tienes a ver 😂

---

## November 22, 2026

[7:34 AM] **Jeni Sis:** Tati la página web 🙂

[10:53 AM] **Tú:**
> _Jeni Sis: Tati la página web 🙂_
[Mensaje de voz]

[10:56 AM] **Jeni Sis:** Dale Tati ponte para esto

[10:57 AM] **Tú:**
> _Jeni Sis: Dale Tati ponte para esto_
Dale voy voy

[8:38 PM] **Tú:** pssss

[8:38 PM] **Tú:** reenviame lo que querias hacer

[8:38 PM] **Tú:** que en la laptop no me cargan los chats

[8:38 PM] __[Llamada]__

[8:40 PM] **Jeni Sis:** Cambiar la tipografía  de lo verde y eliminar lo rojo

[8:40 PM] **Jeni Sis:** [Imagen]

[8:40 PM] **Jeni Sis:** [Imagen]

[8:40 PM] **Jeni Sis:** En las secciones

[8:40 PM] **Jeni Sis:** [Imagen] Vestidos

[8:40 PM] **Jeni Sis:** [Imagen] Suplementos

[8:40 PM] **Jeni Sis:** [Imagen] Enguatadas

[8:40 PM] **Jeni Sis:** [Imagen] Monos y enterizos

[8:40 PM] **Jeni Sis:** [Imagen] Leggins

[8:41 PM] **Jeni Sis:** [Imagen] Conjuntos y sets

[8:41 PM] **Jeni Sis:** [Imagen] Otros artículos

[8:41 PM] **Jeni Sis:** [Imagen] Accesorios

[8:41 PM] **Jeni Sis:** [Imagen]

[8:41 PM] **Jeni Sis:** [Imagen] Tops y Pulovers

[8:42 PM] **Jeni Sis:** [Imagen] Blusas

---

## November 23, 2026

[12:21 AM] **Tú:**
> _Jeni Sis: Imagen: ❤️‍🩹_
Estoy en lo tuyo ,mañana lo subo en la fac a primera hora

[6:53 AM] **Jeni Sis:** Perfect mi amor gracias me avisas cuando esté listo

[10:15 AM] **Tú:**
> _Jeni Sis: Perfect mi amor gracias me avisas cuando esté listo_
Sirvio Rodríguez

[6:12 PM] **Jeni Sis:** Tati a ver la página para cuando a ver

[6:13 PM] **Tú:** Conexión mala

[6:13 PM] **Jeni Sis:** Conexión mala en tu universidad ?

[6:13 PM] **Tú:** [Imagen] Toyeneso

[6:13 PM] **Jeni Sis:** Viste que eres más barco que el titanic

[6:14 PM] **Tú:**
> _Jeni Sis: Conexión mala en tu universidad ?_
En la casa

[6:14 PM] **Tú:** Yo no fui a la uni

[6:14 PM] **Jeni Sis:** Pero tú no me dijiste que ibas en la mañana para tu uni a subirla

[6:16 PM] **Tú:**
> _Jeni Sis: Viste que eres más barco que el titanic_
🫤seguro

[6:17 PM] **Tú:**
> _Jeni Sis: Pero tú no me dijiste que ibas en la mañana para tu uni a subirla_
No he terminado los cambios

[6:18 PM] **Tú:** Son más de lo que parecen

[6:18 PM] **Tú:** [Imagen] Toyeneso

[6:21 PM] **Jeni Sis:** 😩😩😩😩😩

[6:21 PM] **Tú:**
> _Jeni Sis: 😩😩😩😩😩_
[Sticker]

[6:21 PM] **Tú:** Ya no llores casi está

[6:21 PM] **Tú:** Con suerte esta semana ya lo lanzamos

[7:06 PM] **Jeni Sis:** Mira a ver eso por favor la vida

---

## November 24, 2026

[7:46 AM] **Jeni Sis:** Pásame tu tarjeta

[8:17 AM] **Tú:**
> _Jeni Sis: Mira a ver eso por favor la vida_
Yenny si mivida yo estoy en eso

[8:17 AM] **Tú:**
> _Jeni Sis: Pásame tu tarjeta_
Paq

[9:06 AM] **Jeni Sis:** [Mensaje de voz]

[9:39 AM] **Tú:**
> _Jeni Sis: Mensaje de voz_
Na

[9:39 AM] **Tú:** Ven pa enseñarte después

[9:39 AM] **Tú:** La conexión está fula conpinga

[11:44 AM] **Jeni Sis:** Tati

[11:44 AM] **Jeni Sis:** La tarjeta

[11:44 AM] **Jeni Sis:** Tengo q ir recargar

[12:23 PM] **Tú:** Dame la cuenta

[1:33 PM] **Jeni Sis:** Tati

[1:39 PM] **Tú:** [Mensaje de voz]

[1:39 PM] **Tú:** [Mensaje de voz]

[2:08 PM] **Jeni Sis:** Si ya me llegó bien

[2:08 PM] **Jeni Sis:** Dame tu tarjeta

[2:09 PM] **Tú:** Taen ,orita orita

[5:29 PM] **Tú:**
> _Jeni Sis: Imagen: 😍_
Yallegamo :V voaserte eso

[6:24 PM] **Jeni Sis:** Genial

[6:24 PM] **Jeni Sis:** [Sticker]

[6:24 PM] **Tú:** Me tienes de exclavo

[6:24 PM] **Tú:** [Sticker]

[6:25 PM] **Jeni Sis:** [Mensaje de voz]

[6:25 PM] **Tú:** 🤣🤣🤣🤣

[6:25 PM] **Tú:** Es que no me tienes paciencia

[6:25 PM] **Tú:** Ya lo estoy haciendo ,pero Cuba requiere su ritmo 🙂lo sabes

[6:26 PM] **Jeni Sis:** [Mensaje de voz]

[6:30 PM] **Tú:**
> _Jeni Sis: Mensaje de voz_
😂😂😂ojalá fuera eso

[9:14 PM] **Jeni Sis:** Cómo va a?

---

## November 25, 2026

[12:56 AM] **Tú:** Mal 🫤se me vencieron los créditos gratis para subir cosas ,tengo que cambiar la nube a otro enlace

[10:39 AM] **Jeni Sis:** 😩😩😩😩😩

[10:40 AM] **Tú:** [Imagen] Estoy en ello

[10:40 AM] **Tú:** [Imagen] Estoy en ello

[10:40 AM] **Tú:** [Sticker]

[12:07 PM] **Jeni Sis:** Vale ….

[12:08 PM] **Tú:** [Mensaje de voz]

[12:08 PM] **Tú:** [Mensaje de voz]

[12:08 PM] **Tú:** [Mensaje de voz]

[12:11 PM] **Jeni Sis:** [Mensaje de voz]

[12:11 PM] **Jeni Sis:**
> _Tú: Mensaje de voz_
Qué clase de lío

[12:11 PM] **Tú:**
> _Jeni Sis: Mensaje de voz_
[Mensaje de voz]

[12:12 PM] **Tú:** [Mensaje de voz]

[12:12 PM] **Jeni Sis:**
> _Tú: Mensaje de voz_
[Mensaje de voz]

[12:12 PM] **Tú:**
> _Jeni Sis: Mensaje de voz_
[Mensaje de voz]

[12:13 PM] **Tú:** [Mensaje de voz]

[12:15 PM] **Tú:** https://jenny-clothing.onrender.com/

[12:16 PM] **Tú:** Crea par de productos y sesiones de nuevo

[12:16 PM] **Tú:** Ahora te digo los limites free hasta que me ponga algo nuevo de pago y te haga deploy ahi 😂

[12:20 PM] **Tú:** jJCVEsIhsxeX1piRlcDXnn86


Este es el nuevo password

[12:20 PM] **Tú:** Dale chambea

[12:20 PM] **Tú:** para terminarte eso

[12:20 PM] __[Llamada]__

[12:30 PM] **Jeni Sis:**
> _Tú: Mensaje de voz_
Cuánto hay que pagar,

[12:30 PM] **Jeni Sis:** ?

[12:30 PM] **Tú:**
> _Jeni Sis: Cuánto hay que pagar,_
Nada 😆😆😆eso es tarea mía ,al final lo necesito para todas mis cosas

[12:31 PM] **Tú:** Por ahora lo tengo gratis con magia oscura

[12:31 PM] **Tú:** [Sticker]

[12:31 PM] **Tú:** Después te digo el límite de gigas que se pued subir antes de que joda

[12:31 PM] **Tú:** Haz eso

[12:31 PM] **Jeni Sis:** [Mensaje de voz]

[12:31 PM] **Jeni Sis:** [Mensaje de voz]

[12:31 PM] **Tú:**
> _Jeni Sis: Mensaje de voz_
[Mensaje de voz]

[12:31 PM] **Jeni Sis:**
> _Tú: https://jenny-clothing.onrender.com/_
[Mensaje de voz]

[12:32 PM] **Tú:**
> _Jeni Sis: Mensaje de voz_
Nono ,ahora sí te puse la que va

[12:32 PM] **Tú:**
> _Tú: jJCVEsIhsxeX1piRlcDXnn86


Este es el nuevo password_
...

[12:32 PM] **Tú:**
> _Jeni Sis: Mensaje de voz_
Déjame eso a mi

[12:40 PM] __[Notificación del sistema]__

[12:40 PM] __[Notificación del sistema]__

[1:12 PM] **Tú:** [Imagen] Así te gustan las sesiones entonces o quiero algo más ?

[1:24 PM] **Jeni Sis:** _Se eliminó este mensaje_

[1:24 PM] **Jeni Sis:** [Mensaje de album]

[1:24 PM] **Jeni Sis:** [Imagen] Yo quería las secciones tipo así

[1:24 PM] **Jeni Sis:** [Imagen]

[1:24 PM] **Jeni Sis:** Las fotos más grandes y horizontales

[1:25 PM] **Jeni Sis:** [Imagen] Una debajo de la otra

[1:33 PM] **Jeni Sis:** [Imagen] Mira a ver por qué no me deja crear un producto

[1:33 PM] **Jeni Sis:** [Imagen] Eso elimínalo, no hace falta

[1:47 PM] **Tú:**
> _Jeni Sis: [album]_
Okey

[1:48 PM] **Tú:** Algo más aparte de eso ?

[2:25 PM] **Jeni Sis:**
> _Jeni Sis: Imagen_
Ya y quedaría cambiar la tipografía, puedes poner esta . Está bonita

[2:26 PM] **Tú:**
> _Jeni Sis: Ya y quedaría cambiar la tipografía, puedes poner esta . Está bonita_
Okey

[2:26 PM] **Tú:** Sigue subiendo cositas

[2:26 PM] **Tú:** Para que sea más visual la página

[2:31 PM] **Jeni Sis:**
> _Jeni Sis: Imagen: Mira a ver por qué no me deja crear un producto_
Amor tu lees mis mensajes?

[2:31 PM] **Tú:** Ah

[2:32 PM] **Tú:** No no leí

[2:32 PM] **Tú:** [Imagen] Estoy conelprieto dame un chance

[2:32 PM] **Tú:** [Imagen] Estoy conelprieto dame un chance

[2:34 PM] **Jeni Sis:** Oki
